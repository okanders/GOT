#!/bin/bash

bot=$1

# This is the number of runs from each position on each map.
num_runs=3
# Multiply by 2 * <number of maps in maps directory> to get number of total runs.

echo -e "## Game Results against ${bot^}-Bot\n" >> $GITHUB_STEP_SUMMARY

python scripts/run_bots.py -bots student $bot -num_runs $num_runs >> $GITHUB_STEP_SUMMARY