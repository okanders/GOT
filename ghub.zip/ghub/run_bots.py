import argparse
import subprocess
import os
import itertools
import re

# NOTE: This program is intended to be called from project root directory with "python scripts/test_bots.py".
# If it is called from elsewhere, the paths might be messed up.
# Will run on all maps defined in the "maps" directory by default
def main():

    parser = argparse.ArgumentParser(
        prog="test_bots",
        description="Extensively tests two bots against each other on all maps and in different player positions.",
        usage="%(prog)s [options]")
    
    
    parser.add_argument(
        "-bots",
        type=str,
        nargs=2,
        help="The two bots to fight each other (position doesn't matter)."
    )
    parser.add_argument(
        "-num_runs",
        type=int,
        help="How many times to test the bots against each other on each map in each position.",
        default=3
    )
    parser.add_argument(
        "-infinite_time",
        action="store_true",
        help="Whether to call gamerunner.py with the '-runner training' flag to get rid of each turn's time limits."
    )

    args = parser.parse_args()
    bots = tuple(args.bots)
    num_runs = args.num_runs
    infinite_time = args.infinite_time

    valid_bots = {"student", "manual", "random", "attack", "safe", "ta1", "ta2"}
    if bots[0] not in valid_bots or bots[1] not in valid_bots:
        raise ValueError(f"Bot names of {bots[0]} and/or {bots[1]} are invalid!")
    
    maps, win_stats = run_bots(bots, num_runs, infinite_time)
    print_win_stats(bots, maps, win_stats)

def run_bots(bots: tuple[str, str], num_runs: int, infinite_time: bool = False) -> tuple[list[str],dict[str, list[tuple[int, int]]]]:
    """
    Runs the two bots provided by "bots" against each other on each map in both player positions.
    num_runs controls how many games are played on each map in each player position.
    In other words, the total number of games played across all maps
    will be (num_runs * 2 * <how many map files in 'maps' directory>).
    """
    base_tokens = ["python", "gamerunner.py", "-no_msg", "-no_image", "-multi_test", str(num_runs)]
    if infinite_time:
        base_tokens.extend(["-runner", "training"])

    # list of map names taken from the "maps" directory
    maps = [file.name for file in os.scandir("maps")]

    # Maps the bot's name to a list of their wins indexed by the map they were on.
    # Each item in their list is a tuple of two ints representing their wins in each player position.
    bot_win_stats = {bots[0]: [], bots[1]: []}

    for map in maps:
        map_path = f"maps/{map}"
        tokens_for_map = base_tokens + ["-map", map_path, "-bots"]
        
        map_wins = {bots[0]: [0, 0], bots[1]: [0, 0]}
        # iterate over all permuations of the 'bots' list (i.e the 2 ways of ordering the bots)
        for bot_pairs in itertools.permutations(bots):
            # run gamerunner.py and capture it's output (print statements to stdout)
            output = subprocess.run(
                tokens_for_map + list(bot_pairs), check=True, capture_output=True, text=True).stdout
            # print(bot_pairs)
            # print(output)
            # Parse output. Should have 1-2 lines of format "Player _ won _ out of <num_runs> times"
            pattern = re.compile(r"Player (\b\d\b) won (\b\d+\b) out of \d+ times")
            for match in pattern.finditer(output):
                player_i = int(match.group(1)) - 1
                player_name = bot_pairs[player_i]
                wins = int(match.group(2))
                map_wins[player_name][player_i] = wins
                # If you print stuff while running your bot, feel free to parse and process it here!

            
        # Save map win stats to bot_win_stats
        for bot, wins_list in map_wins.items():
            bot_win_stats[bot].append(tuple(wins_list))
    
    return (maps, bot_win_stats)

def print_win_stats(bots: tuple[str, str], map_names: list[str], bot_win_stats: dict[str, list[tuple[int, int]]]):
    p0 = bots[0]
    p1 = bots[1]
    p0_totals = []
    p1_totals = []

    # setup format string for consistent columns in the printed table
    max_map_name_len = max([len(map) for map in map_names])
    player_col_len = 12 # max length of "student wins"
    format_str = f"| {{:^{max_map_name_len}}} | {{:^{player_col_len}}} | {{:^{player_col_len}}} |"

    # print formatted table header
    header = format_str.format("Map Name", f"{p0} wins", f"{p1} wins")
    print(header)
    header_alignment_md = ":----------:" # this is how we indicate center alignment in markdown tables
    print(format_str.format(*[header_alignment_md] * 3))
    
    # Print each map's win stats as a formatted row in the table
    for i, map in enumerate(map_names):
        p0_wins = bot_win_stats[p0][i]
        p0_total = sum(p0_wins)
        p0_str = f"{p0_total} ({p0_wins[0]},{p0_wins[1]})"
        p0_totals.append(p0_total)

        p1_wins = bot_win_stats[p1][i]
        p1_total = sum(p1_wins)
        p1_str = f"{p1_total} ({p1_wins[0]},{p1_wins[1]})"
        p1_totals.append(p1_total)

        print(format_str.format(map, p0_str, p1_str))

    # print total win percentages as last row in table
    num_rounds = sum(p0_totals) + sum(p1_totals)
    percent_format = "**{:.2%}**"
    p0_win_percent = percent_format.format(sum(p0_totals) / num_rounds)
    p1_win_percent = percent_format.format(sum(p1_totals) / num_rounds)
    print(format_str.format("**win percentages**", p0_win_percent, p1_win_percent))



if __name__ == "__main__":
    main()